<?php

$d = opendir('./');

while($f = readdir($d)){
	if($f[0] == '.' || is_dir($f) || strpos($f,'.jpg') === false){continue;}
	
	$c = shell_exec('convert '.$f.' -crop 55x14+27+14 crop/'.$f.' 2>&1');

	shell_exec('convert '.$f.' -negate -type Grayscale -crop 10x14+27+14 letters/'.substr($f,0,-3).'_1.jpg 2>&1');
	shell_exec('convert '.$f.' -negate -type Grayscale -crop 10x14+36+14 letters/'.substr($f,0,-3).'_2.jpg 2>&1');
	shell_exec('convert '.$f.' -negate -type Grayscale -crop 10x14+45+14 letters/'.substr($f,0,-3).'_3.jpg 2>&1');
	shell_exec('convert '.$f.' -negate -type Grayscale -crop 10x14+54+14 letters/'.substr($f,0,-3).'_4.jpg 2>&1');
	shell_exec('convert '.$f.' -negate -type Grayscale -crop 10x14+63+14 letters/'.substr($f,0,-3).'_5.jpg 2>&1');
	shell_exec('convert '.$f.' -negate -type Grayscale -crop 10x14+72+14 letters/'.substr($f,0,-3).'_6.jpg 2>&1');
}

/*
convert 4Dej.jpg -negate -type Grayscale -crop 10x14+27+14 letter1.jpg && convert 4Dej.jpg -negate -type Grayscale -crop 10x14+36+14 letter2.jpg && convert 4Dej.jpg -negate -type Grayscale -crop 10x14+45+14 letter3.jpg && convert 4Dej.jpg -negate -type Grayscale -crop 10x14+54+14 letter4.jpg && convert 4Dej.jpg -negate -type Grayscale -crop 10x14+63+14 letter5.jpg && convert 4Dej.jpg -negate -type Grayscale -crop 10x14+72+14 letter6.jpg
*/

closedir($d);
?>